/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author david
 */
public class Videogame {
    public static void main(String[] args) {
        Game g = new Game("Juego", 800, 500);
        g.start();
    }
}
