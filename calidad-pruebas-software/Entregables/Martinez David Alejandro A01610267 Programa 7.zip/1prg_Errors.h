/*
 * Especificación de todos los posibles errores identificados durante la ejecución
 * normal del programa
 * 
 * David Alejandro Martínez Tristán A01610267
 * Fecha de modificación: 10/05/2021
 */
//.b=14
#ifndef ERRORS_H
#define ERRORS_H
//.d=1
#define ERROR_FILE_NOT_EXISTS 1
#define ERROR_FILE_EMPTY 2
//.d=8
#endif